namespace Emporio_app;

public partial class area_Vendas : Form
{
    public area_Vendas()
    {
        InitializeComponent();
    }
}