﻿namespace Emporio_app;

public class GerenciadorDeVendas
{
    public static void RegistrarVenda(string nomeProduto, int quantidadeVenda, Usuario funcionario, Filial filial)
    {
        Produto? produto = filial.BuscarProduto(nomeProduto);

        if (produto == null)
        {
            MessageBox.Show("Produto não encontrado!");
            return;
        }

        if (produto.Estoque >= quantidadeVenda)
        {
            produto.Estoque -= quantidadeVenda;
            produto.QuantidadeVendida += quantidadeVenda;

            Venda venda = new Venda(produto, quantidadeVenda, funcionario, filial);
            MessageBox.Show($"Venda registrada com sucesso! Produto: {produto.Nome}, Quantidade: {quantidadeVenda}");
            MessageBox.Show($"Estoque atualizado: {produto.Estoque} unidades restantes.");
        }
        else
        {
            MessageBox.Show("Estoque insuficiente para realizar a venda!");
        }
    }
}