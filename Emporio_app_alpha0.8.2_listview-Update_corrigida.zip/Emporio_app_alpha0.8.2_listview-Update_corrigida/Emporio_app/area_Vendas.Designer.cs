using System.ComponentModel;

namespace Emporio_app;

partial class area_Vendas
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(area_Vendas));
        pictureBox1 = new System.Windows.Forms.PictureBox();
        pictureBox2 = new System.Windows.Forms.PictureBox();
        pictureBox3 = new System.Windows.Forms.PictureBox();
        pictureBox4 = new System.Windows.Forms.PictureBox();
        pictureBox5 = new System.Windows.Forms.PictureBox();
        pictureBox6 = new System.Windows.Forms.PictureBox();
        ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
        SuspendLayout();
        // 
        // pictureBox1
        // 
        pictureBox1.Image = ((System.Drawing.Image)resources.GetObject("pictureBox1.Image"));
        pictureBox1.Location = new System.Drawing.Point(708, 408);
        pictureBox1.Name = "pictureBox1";
        pictureBox1.Size = new System.Drawing.Size(100, 50);
        pictureBox1.TabIndex = 0;
        pictureBox1.TabStop = false;
        // 
        // pictureBox2
        // 
        pictureBox2.Image = ((System.Drawing.Image)resources.GetObject("pictureBox2.Image"));
        pictureBox2.Location = new System.Drawing.Point(-31, 0);
        pictureBox2.Name = "pictureBox2";
        pictureBox2.Size = new System.Drawing.Size(100, 50);
        pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox2.TabIndex = 1;
        pictureBox2.TabStop = false;
        // 
        // pictureBox3
        // 
        pictureBox3.Image = ((System.Drawing.Image)resources.GetObject("pictureBox3.Image"));
        pictureBox3.Location = new System.Drawing.Point(129, 262);
        pictureBox3.Name = "pictureBox3";
        pictureBox3.Size = new System.Drawing.Size(100, 50);
        pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox3.TabIndex = 2;
        pictureBox3.TabStop = false;
        // 
        // pictureBox4
        // 
        pictureBox4.Image = ((System.Drawing.Image)resources.GetObject("pictureBox4.Image"));
        pictureBox4.Location = new System.Drawing.Point(730, -13);
        pictureBox4.Name = "pictureBox4";
        pictureBox4.Size = new System.Drawing.Size(100, 50);
        pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox4.TabIndex = 3;
        pictureBox4.TabStop = false;
        // 
        // pictureBox5
        // 
        pictureBox5.Image = ((System.Drawing.Image)resources.GetObject("pictureBox5.Image"));
        pictureBox5.Location = new System.Drawing.Point(-31, 408);
        pictureBox5.Name = "pictureBox5";
        pictureBox5.Size = new System.Drawing.Size(100, 50);
        pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox5.TabIndex = 4;
        pictureBox5.TabStop = false;
        // 
        // pictureBox6
        // 
        pictureBox6.Image = ((System.Drawing.Image)resources.GetObject("pictureBox6.Image"));
        pictureBox6.Location = new System.Drawing.Point(161, 180);
        pictureBox6.Name = "pictureBox6";
        pictureBox6.Size = new System.Drawing.Size(100, 50);
        pictureBox6.TabIndex = 5;
        pictureBox6.TabStop = false;
        // 
        // area_Vendas
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(800, 450);
        Controls.Add(pictureBox6);
        Controls.Add(pictureBox5);
        Controls.Add(pictureBox4);
        Controls.Add(pictureBox3);
        Controls.Add(pictureBox2);
        Controls.Add(pictureBox1);
        Text = "area_Vendas";
        ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
        ResumeLayout(false);
    }

    private System.Windows.Forms.PictureBox pictureBox6;

    private System.Windows.Forms.PictureBox pictureBox5;

    private System.Windows.Forms.PictureBox pictureBox4;

    private System.Windows.Forms.PictureBox pictureBox2;
    private System.Windows.Forms.PictureBox pictureBox3;

    private System.Windows.Forms.PictureBox pictureBox1;

    #endregion
}