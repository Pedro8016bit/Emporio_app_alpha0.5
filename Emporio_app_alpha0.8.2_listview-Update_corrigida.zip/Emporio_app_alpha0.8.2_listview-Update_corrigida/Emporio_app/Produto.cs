﻿namespace Emporio_app;

public class Produto
{
    public string Nome { get; set; }
    public double Preco { get; set; }
    public int Estoque { get; set; }
    public int QuantidadeVendida { get; set; }
    public string FaixaEtaria { get; set; }

    public Produto(string nome, double preco, int estoque, string faixaEtaria)
    {
        Nome = nome;
        Preco = preco;
        Estoque = estoque;
        FaixaEtaria = faixaEtaria;
        QuantidadeVendida = 0;
    }  
}