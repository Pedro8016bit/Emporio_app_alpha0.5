namespace Emporio_app;

public partial class Registrar_vendas : Form
{
    public Registrar_vendas()
    {
        InitializeComponent();
    }
}