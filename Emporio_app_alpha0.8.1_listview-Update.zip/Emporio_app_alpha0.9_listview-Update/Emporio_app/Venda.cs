﻿namespace Emporio_app;

public class Venda
{
    public Produto Produto { get; set; }
    public int Quantidade { get; set; }
    public DateTime DataVenda { get; set; }
    public Usuario Funcionario { get; set; }
    public Filial Filial { get; set; }

    public Venda(Produto produto, int quantidade, Usuario funcionario, Filial filial)
    {
        Produto = produto;
        Quantidade = quantidade;
        DataVenda = DateTime.Now;
        Funcionario = funcionario;
        Filial = filial;
    }
}