﻿namespace Emporio_app;

public class Filial
{
    public string Nome { get; set; }
    public List<Produto> Produtos { get; set; }

    public Filial(string nome)
    {
        Nome = nome;
        Produtos = new List<Produto>();
    }

    public Produto? BuscarProduto(string nome)
    {
        return Produtos.Find(p => p.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase));
    }
}